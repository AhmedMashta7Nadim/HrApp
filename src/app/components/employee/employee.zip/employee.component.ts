import { Component, OnInit } from '@angular/core';
import { Employee } from '../../Model/employee/employee';
import { EmployeeService } from '../../Model/employee/employee.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  emps: Employee[] = [];
  newEmployee: Employee = new Employee();
  selectedEmployee: Employee | undefined;
  showAddEmployeeForm: boolean = false;
  selectedFile: File | null = null;

  constructor(private empsService: EmployeeService) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  getEmployees(): void {
    this.empsService.getEmployees().subscribe({
      next: (employees) => {
        this.emps = employees;
      },
      error: (error) => {
        console.error('Error fetching employees', error);
      },
      complete: () => {
        console.log('Employee data fetching completed');
      }
    });
  }

  onFileChange(event: any): void {
    if (event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
    }
  }

  addEmployee(): void {
    if (this.validateEmployee(this.newEmployee)) {
      var formData = new FormData();
      formData.append('Name', this.newEmployee.name || '');
      formData.append('Father', this.newEmployee.father || '');
      formData.append('LastName', this.newEmployee.lastName || '');
      formData.append('Mother', this.newEmployee.mother || '');
      formData.append('BirthDate', this.newEmployee.birthDate?.toString() || '');
      formData.append('date_of_employment', this.newEmployee.date_of_employment?.toString() || '');
      formData.append('Salary_basis', this.newEmployee.salary_basis?.toString() || '');
      formData.append('Functional_ID', this.newEmployee.functional_ID || '');
      formData.append('CityId', this.newEmployee.cityId || '');
      formData.append('UniverCityId', this.newEmployee.univerCityId || '');
      formData.append('Gendar', this.newEmployee.gendar || '');
      if (this.selectedFile) {
        formData.append('Img', this.selectedFile);
      }

      this.empsService.addEmployee(formData as unknown as Employee).subscribe({
        next: (response) => {
          console.log('Employee added successfully', response);
          this.emps.push(response);
          this.newEmployee = new Employee();
          this.toggleAddEmployeeForm();
        },
        error: (error) => {
          console.error('Error adding employee', error);
        }
      });
    } else {
      console.error('Validation failed for the employee data');
    }
  }

  validateEmployee(employee: Employee): boolean {
    return !!(
      employee.name && employee.father && employee.lastName &&
      employee.mother && employee.birthDate && employee.date_of_employment &&
      employee.salary_basis && employee.functional_ID && employee.cityId &&
      employee.univerCityId && employee.gendar
    );
  }

  updateEmployee(): void {
    if (this.selectedEmployee && this.selectedEmployee.id) {
      this.empsService.updateEmployee(this.selectedEmployee).subscribe({
        next: () => {
          console.log('Employee updated successfully');
          this.getEmployees();
          this.selectedEmployee = undefined;
        },
        error: (error) => {
          console.error('Error updating employee', error);
        }
      });
    }
  }

  deleteEmployee(id: string | undefined): void {
    if (!id) {
      console.error('Invalid Employee ID');
      return;
    }

    this.empsService.deleteEmployee(id).subscribe({
      next: () => {
        console.log('Employee deleted successfully');
        this.emps = this.emps.filter(employee => employee.id !== id);
      },
      error: (error) => {
        console.error(`Error deleting employee with ID ${id}`, error);
      }
    });
  }

  selectEmployee(employee: Employee): void {
    this.selectedEmployee = { ...employee };
  }

  toggleAddEmployeeForm(): void {
    this.showAddEmployeeForm = !this.showAddEmployeeForm;
  }

  trackById(index: number, employee: Employee): string | undefined {
    return employee.id;
  }
}
